package Lab14.sampleJavaFX;

public class Controller {
}
